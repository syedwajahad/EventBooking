﻿using System.ComponentModel.DataAnnotations;

namespace EventBooking.Domain.Entities
{
    public class TicketTransaction
    {

        [Key]
        public Guid TicketId { get; set; }

        [Key]
        public Guid TransactionId { get; set; }

        public Ticket Ticket { get; set; }
        public Transaction Transaction { get; set; }
    }
}
