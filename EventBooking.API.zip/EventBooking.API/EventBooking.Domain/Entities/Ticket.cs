﻿namespace EventBooking.Domain.Entities
{
    public class Ticket
    {
        public Guid Id { get; set; }
        public Guid EventId { get; set; }
        public string TicketNumber { get; set; }
        public string Status { get; set; } // Enum: Reserved, Purchased, Cancelled
        public DateTime? ReservationExpiryTime { get; set; }
        public DateTime? PurchasedAt { get; set; }
        public DateTime CreatedAt { get; set; }

        public Event Event { get; set; }
        public ICollection<TicketTransaction> TicketTransactions { get; set; }
    }
}
