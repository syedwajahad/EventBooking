﻿namespace EventBooking.Domain.Entities
{
    public class Transaction
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }
        public decimal Amount { get; set; }
        public string PaymentMethod { get; set; } // Card, UPI, etc.
        public string Status { get; set; } // Success, Failed, Pending
        public string TransactionReference { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? CompletedAt { get; set; }

        public User User { get; set; }
        public ICollection<TicketTransaction> TicketTransactions { get; set; }
    }
}
