﻿
using EventBooking.Domain.Entities;

namespace EventBooking.Application.Common.Interfaces.Security
{
    public interface IJwtTokenService
    {
        string GenerateToken(User user);
        Guid? ValidateToken(string token);
    }
}
