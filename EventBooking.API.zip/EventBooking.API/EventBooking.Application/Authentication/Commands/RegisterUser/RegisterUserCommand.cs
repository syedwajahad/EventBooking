﻿
using EventBooking.Application.Authentication.Dtos;
using MediatR;

namespace EventBooking.Application.Authentication.Commands.RegisterUser
{
    public class RegisterUserCommand:IRequest<AuthResponseDto>
    {
        public string Email { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
