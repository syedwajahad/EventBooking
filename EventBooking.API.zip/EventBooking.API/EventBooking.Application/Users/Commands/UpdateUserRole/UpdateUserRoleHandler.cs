﻿using EventBooking.Application.Common.Interfaces.Persistence;
using MediatR;
using Microsoft.AspNetCore.Builder;

namespace EventBooking.Application.Users.Commands.UpdateUserRole
{
    public class UpdateUserRoleHandler : IRequestHandler<UpdateUserRole,Unit>
    {
        private readonly IApplicationDbContext _context;

        public UpdateUserRoleHandler(IApplicationDbContext context) { _context = context; }

        public async Task<Unit>Handle(UpdateUserRole request, CancellationToken cancellationToken)
        {
            var user = await _context.Users.FindAsync(request.Id);
            if (user == null)
              throw new ArgumentException("User not found");

                user.Role = request.Role;
                await _context.SaveChangesAsync(cancellationToken);
                return Unit.Value;

            
        }
    }
}
