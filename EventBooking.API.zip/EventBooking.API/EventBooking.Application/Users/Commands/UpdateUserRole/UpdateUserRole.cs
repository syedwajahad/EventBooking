﻿
using MediatR;

namespace EventBooking.Application.Users.Commands.UpdateUserRole
{
    public class UpdateUserRole:IRequest<Unit>
    {
        public Guid Id { get; set; }
        public string Role { get; set; }
    }
}
