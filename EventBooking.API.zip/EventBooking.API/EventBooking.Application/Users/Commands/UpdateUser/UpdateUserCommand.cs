﻿
using EventBooking.Application.Users.Dtos;
using MediatR;

namespace EventBooking.Application.Users.Commands.UpdateUser
{
    public class UpdateUserCommand:IRequest<Unit>
    {
        public Guid Id { get; set; }
        public string UserName { get; set; }

    }
}
    