﻿using EventBooking.Application.Common.Interfaces.Persistence;
using MediatR;

namespace EventBooking.Application.Users.Commands.UpdateUser
{
    public class UpdateUserHandler:IRequestHandler<UpdateUserCommand, Unit>
    {
        private readonly IApplicationDbContext _context;

        public UpdateUserHandler(IApplicationDbContext context)
        {  _context = context; }

        public async Task<Unit> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var user = await _context.Users.FindAsync(request.Id);
            if (user == null) throw new Exception("User not found");
            user.Username = request.UserName;
            user.UpdatedAt= DateTime.UtcNow;
            await _context.SaveChangesAsync(cancellationToken);
            return Unit.Value;

        }
    }
}
