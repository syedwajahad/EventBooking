﻿

using EventBooking.Application.Users.Dtos;
using MediatR;

namespace EventBooking.Application.Users.Commands.DeleteUser
{
    public record DeleteUserCommand(Guid Id):IRequest<Unit>;
    
}
