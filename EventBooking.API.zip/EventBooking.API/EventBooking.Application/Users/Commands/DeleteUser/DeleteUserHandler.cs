﻿

using EventBooking.Application.Common.Interfaces.Persistence;
using EventBooking.Application.Users.Dtos;
using MediatR;

namespace EventBooking.Application.Users.Commands.DeleteUser
{
    public class DeleteUserHandler:IRequestHandler<DeleteUserCommand,Unit>
    {
        private readonly IApplicationDbContext _context;
            public DeleteUserHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Unit> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
        {
            var user = await _context.Users.FindAsync(request.Id);
            if (user == null) { throw new Exception("User not found"); }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
            return Unit.Value;


        }
    }
}
