﻿using EventBooking.Application.Common.Interfaces.Persistence;
using EventBooking.Application.Users.Dtos;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace EventBooking.Application.Users.Queries.GetCurrentUser
{
    public class GetCurrentUserHandler : IRequestHandler<GetCurrentUserQuery, UserDto>
    {
        private readonly IApplicationDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public GetCurrentUserHandler(IApplicationDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }

        public async Task<UserDto> Handle(GetCurrentUserQuery request, CancellationToken cancellationToken)
        {
         
            var userId = _httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

            try
            {
                if (string.IsNullOrWhiteSpace(userId) || !Guid.TryParse(userId, out var guid))
                    return null;

                Console.WriteLine($"Searching for user with GUID: {guid}");

                // Now this should work without SqlNullValueException
                var user = await _context.Users.FindAsync(guid);

                if (user == null)
                {
                    Console.WriteLine($"No user found with GUID: {guid}");
                    return null;
                }

                Console.WriteLine($"Found user: {user.Id}");

                return new UserDto
                {
                    Id = user.Id,
                    Email = user.Email ?? "",           
                    Username = user.Username ?? "",     
                    Role = user.Role ?? "",             
                    
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                return null;
            }

        }
    }

    }


