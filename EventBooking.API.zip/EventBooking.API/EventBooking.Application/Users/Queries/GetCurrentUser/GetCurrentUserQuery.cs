﻿
using EventBooking.Application.Users.Dtos;
using MediatR;

namespace EventBooking.Application.Users.Queries.GetCurrentUser
{
    public class GetCurrentUserQuery : IRequest<UserDto>
    {
    }
}
