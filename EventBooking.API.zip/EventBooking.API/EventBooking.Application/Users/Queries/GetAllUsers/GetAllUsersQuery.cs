﻿
using EventBooking.Application.Users.Dtos;
using MediatR;

namespace EventBooking.Application.Users.Queries.GetAllUsers
{
    public class GetAllUsersQuery:IRequest<List<UserDto>> { }

}
