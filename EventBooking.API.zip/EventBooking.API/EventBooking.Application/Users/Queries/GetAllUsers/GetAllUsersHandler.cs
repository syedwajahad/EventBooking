﻿
using EventBooking.Application.Common.Interfaces.Persistence;
using EventBooking.Application.Users.Dtos;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace EventBooking.Application.Users.Queries.GetAllUsers
{
    public class GetAllUsersHandler: IRequestHandler<GetAllUsersQuery, List<UserDto>>
    {
        private readonly IApplicationDbContext _context;

        public GetAllUsersHandler(IApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<List<UserDto>> Handle(GetAllUsersQuery request, CancellationToken cancellationToken)
        {
            return await _context.Users
                .Select(u => new UserDto
                {
                    Id = u.Id,
                    Email = u.Email,
                    Username = u.Username,
                    Role = u.Role
                })
                .ToListAsync(cancellationToken);
        }
    }
}
