﻿using EventBooking.Application.Common.Interfaces.Persistence;
using EventBooking.Application.Users.Dtos;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Threading;

namespace EventBooking.Application.Users.Queries.GetUserById
{
    public class GetUserByIdHandler:IRequestHandler<GetUserByIdQuery,UserDto>
    {
        private readonly IApplicationDbContext _context;

        public GetUserByIdHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<UserDto> Handle(GetUserByIdQuery request, CancellationToken token)
        {
           
            var user = await _context.Users
            .Where(u => u.Id == request.Id)
            .Select(u => new UserDto
            {
                Id = u.Id,
                Email = u.Email,
                Username = u.Username,
                Role = u.Role
            })
            .FirstOrDefaultAsync(token);

            return user;
        }
    }
}
