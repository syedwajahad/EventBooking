﻿using EventBooking.Application.Users.Dtos;
using MediatR;

namespace EventBooking.Application.Users.Queries.GetUserById
{
    public class GetUserByIdQuery:IRequest<UserDto>
    {
        public Guid Id { get; set; }
    }
}
