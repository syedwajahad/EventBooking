﻿

namespace EventBooking.Application.Events.Dtos
{
    public class EventDto
    {
        public Guid Id { get; set; }
        public string Title { get; set; }

        public string Description { get; set; }

        public DateTime ScheduledAt { get; set; }

        public string OrganizerId { get; set; } // If you want role checks

        public bool IsPublished { get; set; }

    }
}
