﻿
using EventBooking.Application.Common.Interfaces.Persistence;
using EventBooking.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Builder;

namespace EventBooking.Application.Events.Commands.CreateEvent
{
    public class CreateEventHandler : IRequestHandler<CreateEventCommand, Guid>
    {
        private readonly IApplicationDbContext _context;

        public CreateEventHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Guid> Handle(CreateEventCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var entity = new Event
                {
                    Id = Guid.NewGuid(),
                    Title = request.Title,
                    ScheduledAt = request.ScheduledAt,
                    OrganizerId = request.OrganizerId,
                    CreatedAt=DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow,
                    EndDate = DateTime.UtcNow,
                    IsPublished = false

                };
                _context.Events.Add(entity);
                await _context.SaveChangesAsync(cancellationToken);

                return entity.Id;


            }
            catch (Exception ex) { }
            return default(Guid);
            }
        
    }
    }


