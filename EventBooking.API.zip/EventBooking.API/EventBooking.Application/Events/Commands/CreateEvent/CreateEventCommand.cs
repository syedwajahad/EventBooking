﻿using MediatR;

namespace EventBooking.Application.Events.Commands.CreateEvent
{
    public class CreateEventCommand:IRequest<Guid>
    {
        public string Title { get; set; }
        public DateTime ScheduledAt { get; set; }
        public string OrganizerId { get; set; }
    }
}
