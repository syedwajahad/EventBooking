﻿
using EventBooking.Application.Events.Dtos;
using MediatR;

namespace EventBooking.Application.Events.Commands.UpdateEvent
{
    public class UpdateEventCommand:IRequest<Unit>
    {
        public Guid Id { get; set; }
        public string Title { get; set; }

        public DateTime ScheduledAt { get; set; }

    }
}
