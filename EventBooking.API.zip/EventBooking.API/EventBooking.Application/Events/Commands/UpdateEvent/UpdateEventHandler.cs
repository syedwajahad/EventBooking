﻿
using EventBooking.Application.Common.Interfaces.Persistence;
using EventBooking.Domain.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace EventBooking.Application.Events.Commands.UpdateEvent
{
    public class UpdateEventHandler : IRequestHandler<UpdateEventCommand,Unit>
    {
        private readonly IApplicationDbContext _context;

        public UpdateEventHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<Unit> Handle(UpdateEventCommand request, CancellationToken cancellationToken)
        {
            //var entity = await _context.Events.FindAsync(request.Id);
            var entity = await _context.Events
    .SingleOrDefaultAsync(e => e.Id == request.Id, cancellationToken);
            if (entity == null) throw new Exception("Not Found");

            entity.Title = request.Title;
                entity.ScheduledAt = request.ScheduledAt;

            await _context.SaveChangesAsync(cancellationToken);
            return Unit.Value;
        }
    }
}
