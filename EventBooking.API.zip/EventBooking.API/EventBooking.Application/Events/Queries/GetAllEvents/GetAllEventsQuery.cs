﻿
using EventBooking.Application.Events.Dtos;
using MediatR;

namespace EventBooking.Application.Events.Queries.GetAllEvents
{
    public record GetAllEventsQuery(string? Filter):IRequest<List<EventDto>>;
    
}
