﻿
using EventBooking.Application.Common.Interfaces.Persistence;
using EventBooking.Application.Events.Dtos;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace EventBooking.Application.Events.Queries.GetAllEvents
{
    public class GetAllEventsHandler : IRequestHandler<GetAllEventsQuery, List<EventDto>>
    {

        private readonly IApplicationDbContext _context;

        public GetAllEventsHandler(IApplicationDbContext context) => _context = context;
        public async Task<List<EventDto>> Handle(GetAllEventsQuery request, CancellationToken cancellationToken)
        {
            return await _context.Events.Where(e => string.IsNullOrEmpty(request.Filter) || e.Title.Contains(request.Filter))
                .Select(e => new EventDto
                {
                    Id = e.Id,
                    Title = e.Title,
                    Description = e.Description,
                    ScheduledAt = e.ScheduledAt,
                    OrganizerId = e.OrganizerId,
                    IsPublished = e.IsPublished
                }).ToListAsync(cancellationToken);
        }
    }
}
