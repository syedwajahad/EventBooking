﻿using EventBooking.Application.Events.Dtos;
using MediatR;

namespace EventBooking.Application.Events.Queries.GetEventById
{
    public class GetEventById:IRequest<EventDto>
    {
        public Guid Id { get; set; }

        public GetEventById(Guid id) { 
            Id = id;
            }

    }
   
}
