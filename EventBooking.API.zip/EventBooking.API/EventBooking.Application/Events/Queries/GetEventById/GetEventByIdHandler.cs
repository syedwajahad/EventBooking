﻿
using EventBooking.Application.Common.Interfaces.Persistence;
using EventBooking.Application.Events.Dtos;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace EventBooking.Application.Events.Queries.GetEventById
{
    public class GetEventByIdHandler:IRequestHandler<GetEventById, EventDto>
    {
        private readonly IApplicationDbContext _context;
        public GetEventByIdHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<EventDto> Handle(GetEventById request, CancellationToken cancellationToken)
        {
            var evt = await _context.Events
                 .Where(e => e.Id == request.Id)
                 .Select(e => new EventDto
                 {
                     Id = e.Id,
                     Title = e.Title,
                     Description = e.Description,
                     ScheduledAt = e.ScheduledAt,
                     IsPublished = e.IsPublished
                 })
                 .FirstOrDefaultAsync(cancellationToken);

            return evt!;
            
        }
    }
}
