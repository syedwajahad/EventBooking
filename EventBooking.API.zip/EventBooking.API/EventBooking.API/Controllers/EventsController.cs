﻿using EventBooking.Application.Events.Commands.CreateEvent;
using EventBooking.Application.Events.Commands.UpdateEvent;
using EventBooking.Application.Events.Queries.GetAllEvents;
using EventBooking.Application.Events.Queries.GetEventById;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Update.Internal;

namespace EventBooking.API.Controllers
{
    [Authorize]
    [Route("api/events")]
    public class EventsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public EventsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllEvents([FromQuery] string? Filter)
        => Ok(await _mediator.Send(new GetAllEventsQuery(Filter)));



        
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateEventCommand command)
        {
            var eventId = await _mediator.Send(command);
            return CreatedAtAction(nameof(Create), new { id = eventId }, eventId);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetEventById(Guid id)
        {
            var result = await _mediator.Send(new GetEventById(id));
            if (result == null)
                return NotFound();

            return Ok(result);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(Guid id, [FromBody]UpdateEventCommand command)
        {
            if (id != command.Id) 
            return BadRequest("Event ID mismatch.");

            await _mediator.Send(command);
            return Ok();


        }


    }
}
