﻿using EventBooking.Application.Users.Commands.DeleteUser;
using EventBooking.Application.Users.Commands.UpdateUser;
using EventBooking.Application.Users.Commands.UpdateUserRole;
using EventBooking.Application.Users.Queries.GetAllUsers;
using EventBooking.Application.Users.Queries.GetCurrentUser;
using EventBooking.Application.Users.Queries.GetUserById;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Query.Internal;

namespace EventBooking.API.Controllers
{

    [ApiController]
    [Route("api/users")]
    public class UsersController : ControllerBase
    {
        private readonly IMediator _mediator;
        public UsersController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        [Authorize(Roles = "Customer")]
        public async Task<IActionResult> GetAll() => Ok(await _mediator.Send(new GetAllUsersQuery()));

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var user = await _mediator.Send(new GetUserByIdQuery { Id = id });
            return Ok(user);
        }
        [HttpGet("me")]
        public async Task<IActionResult> GetCurrentUser() => Ok(await _mediator.Send(new GetCurrentUserQuery()));

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, UpdateUserCommand cmd)
        {
            cmd.Id = id;
            await _mediator.Send(cmd);
            return Ok();

        }
        [Authorize(Roles = "Admin")]
        [HttpDelete("{id}")]
        public async Task<IActionResult>Delete(Guid id)
        {
            await _mediator.Send(new DeleteUserCommand(id));
            return Ok();
                
        }
        [Authorize(Roles = "Admin")]
        [HttpPut("{id}/role")]
        public async Task<IActionResult> UpdateRole(Guid id, [FromBody] UpdateUserRole cmd)
        {
            if (id != cmd.Id)
                return BadRequest("Route id does not match body id");

            await _mediator.Send(cmd);
            return Ok();
        }


    }
}
