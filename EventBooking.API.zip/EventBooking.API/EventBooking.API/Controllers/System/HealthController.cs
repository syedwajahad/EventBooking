﻿using Microsoft.AspNetCore.Mvc;
using EventBooking.Infrastructure.Persistence;

namespace EventBooking.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class HealthController : ControllerBase
    {
        private readonly ApplicationDbContext _dbContext;

        public HealthController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> GetHealth()
        {
            // Try connecting to the database
            var canConnect = await _dbContext.Database.CanConnectAsync();

            if (canConnect)
            {
                return Ok(new
                {
                    status = "Healthy",
                    dbConnection = "Successful",
                    timestamp = DateTime.UtcNow
                });
            }

            return StatusCode(503, new
            {
                status = "Unhealthy",
                dbConnection = "Failed",
                timestamp = DateTime.UtcNow
            });
        }
    }
}
